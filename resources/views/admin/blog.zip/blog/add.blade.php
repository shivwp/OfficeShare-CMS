@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header ">
        <h4 class="card-title">
            {{ $title }} 
        </h4>
    </div>
<div class="card-body">
        <form action="{{ route("admin.blog.store") }}" method="POST" enctype="multipart/form-data">
            @csrf
              <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                <label for="name">Title</label>
                <input type="text" class="form-control" name="title" value="{{isset($edblog->title)?$edblog->title:''}}">
                </div>
                <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                    <label for="name">Media Type</label>
                    <input type="radio" name="media_type" value="image" 
                    {{isset($edblog) && $edblog=="image"?"checked":''}}> Image 
                    <input type="radio" name="media_type" value="video" 
                    {{isset($edblog) && $edblog=="video"?"checked":''}}> Video 
                </div>
                <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                    <label for="name">Upload File</label>
                    <input type="file" name="media" class="form-control">
               </div>
                <div class="form-group {{$errors->has('email')?'has-error' : '' }}">
                    <label for="email">Short Description</label>
                    <textarea style="height:400px !important;" class="editor1 form-control"
                     name="sd">{{isset($edblog->short_description)?$edblog->short_description:''}}</textarea>
                </div>
                <div class="form-group {{$errors->has('email')?'has-error' : '' }}">
                    <label for="email">Full Description</label>
                    <textarea style="height:400px !important;" class="editor1 form-control"
                     name="fd">{{isset($edblog->full_description)?$edblog->full_description:''}}</textarea>
                </div>
                <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                <label for="name">Meta Title</label>
                <input type="text" id="name" name="meta_title" class="form-control" 
                value="{{isset($edblog->meta_title)?$edblog->meta_title:''}}" >
                </div>
                <div class="form-group {{$errors->has('email')?'has-error' : '' }}">
                    <label for="email">Meta Keyword</label>
                <textarea  class=" form-control" name="meta_keyword">{{isset($edblog->meta_keyword)?$edblog->meta_keyword:''}}</textarea>
                </div>
                <div>
                <input class="btn btn-danger" type="submit" value="{{ trans('global.save') }} & Update">
            </div>
        </form>
    </div>
</div>
@endsection
