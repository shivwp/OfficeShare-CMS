@extends('layouts.admin')

@section('title',$title)

@section('content')



<!-- /Row -->
<div class="card-header ">

 

    <div class="row">

        <div class="col-sm-6">

            <h4 class="card-title">

               {{$title}}

            </h4>

        </div>

        <div class="col-sm-6 text-right">

            @can('blog_create')

            <div style="margin-bottom: 10px;" class="row">

                <div class="col-lg-12">

                    <a class="btn btn-success" href="{{ route('admin.blog.create') }}" >

                        {{ trans('global.add') }} Page

                    </a>

                </div>

            </div>

        @endcan

        </div>

    </div>

</div>

<div class="card">

 

      <div class="card-body">

        <div class="table-responsive">

            <table class=" table table-striped table-hover datatable datatable-User " id="example">

             <thead >

              <tr >

                <th>#Sr.</th>

                <th>Title</th>
                <th>Media</th>
                <th>User</th>
                <th>Date</th>
                <th>Status</th>
                <th>Action</th>

              </tr>

            </thead>

                <tbody class="c">

                      @isset($blog)

                      <?php $i=1; ?>

                        @foreach($blog as $item)

                        <tr id='{{ $item->id }}'>

                          <td>{{ $i++ }}</td>

                          <td>{{ $item->title }}</td>

                          <td>
                              @if($item->media_type=="image")
                              <img src="{{url('')}}/{{$item->media}}" alt="img" style="height:100px;width:70px;">
                              @else
                               <video>
                                   <source src="{{url('')}}/{{$item->media}}">
                               </video>
                              @endif
                          </td>
                          <td>

                            @can('blog_edit')

                                    <a class="btn btn-xs btn-info" href="{{ route('admin.blog.edit',$item->id) }}">

                                     <i class="far fa-edit"></i>

                                    </a>

                             @endcan

                            @can('blog_delete')

                <a href="javascript:void(0)" class="btn btn-xs btn-danger delblog" ><i class="fas fa-trash-alt"></i></a>

                 <a href="{{ route('admin.blog.show',$item->id) }}" class="btn btn-xs btn-primary" ><i class="fas fa-eye"></i></a>

                            @endcan

                          </td>

                        </tr>

                        @endforeach

                        @endisset

                </tbody>

            </table>

        </div>

    </div>

</div>


@push('ajax-script')
     <script type="text/javascript">



      $(".delblog").click(function(event) {

      var id=$(this).parents('tr').attr('id');

const swalWithBootstrapButtons = Swal.mixin({

  customClass: {

    confirmButton: 'btn btn-success',

    cancelButton: 'btn btn-danger'

  },

  buttonsStyling: false

})

swalWithBootstrapButtons.fire({

  title: 'Are you sure?',

  text: "You won't be able to revert this!",

  icon: 'warning',

  showCancelButton: true,

  confirmButtonText: 'Yes, delete it!',

  cancelButtonText: 'No, cancel!',

  reverseButtons: true

}).then((result) => {

  if (result.isConfirmed) {

     $.ajax({

      url: "{{ url('admin/blog') }}/"+id,

      type: 'DELETE',

      data:{ 

        id:id,

           _token:'{{ csrf_token() }}'

                },

      success:function(data)

      { swalWithBootstrapButtons.fire(

                'Deleted!',

                'Your file has been deleted.',

                'success'

              )

      

        $("#"+id).remove() 

      }

    })

       

        

 

  } else if (

    /* Read more about handling dismissals below */

    result.dismiss === Swal.DismissReason.cancel

  ) {

    swalWithBootstrapButtons.fire(

      'Cancelled',

      'Your imaginary file is safe :)',

      'error'

    )

  }

}) 

      });

    </script>

    


    

    <!-- for data search -->

    <script>

    $(document).ready(function(){

      $("#InputCat").on("keyup", function() {

        var value = $(this).val().toLowerCase();

        $(".c tr").filter(function() {

          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)

        });

      });

    });

    </script>  

@endpush

@endsection

